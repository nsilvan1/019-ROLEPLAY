
var soundSpt = {}
// var vol = 50
var retorno = {}
var idXBL = ''
var closedApp = false
$(() => {
    soundSpt.init();
    idXBL = 'discord:708738486370435163'
    carregaPlaylist()
    window.addEventListener("message", function (event) {
        switch (event.data.action) {
            case "openUI":
                $("body").show()
                retorno = event.data
                vol = retorno.volume
                Radios_volum = vol
                volumeMusic = vol
                $('.player__volume_bar').attr('style', `width: ${vol}%`)
                token = retorno.token
                license = retorno.license
                youtube_key = retorno.youtube
                linkmusic = retorno.linkurl
                playSound = retorno.playSound
                idXBL = retorno.idXbl
                if (playSound) {
                    total = retorno.total
                    played = retorno.played
                } else {
                    total = '0'
                    played = '0'
                }
                carregaPlaylist()
                break;
            case "changetextv":
                retorno = event.data
                Radios_volum = retorno.vol
                volumeMusic = retorno.volume
                $('.player__volume_bar').attr('style', `width: ${volumeMusic}%`)
                break;
            case "TimeVid":
                retorno = event.data
                total = retorno.total
                played = retorno.played
                timeProgessVideo(total, played)
                break;
            case "NextMusic":
                retorno = event.data
                closedApp = retorno.close
                nextMusic(closedApp);
                break;
            case "changetextl":
                retorno = event.data
                loop = retorno.loop
                break;
            case "closeUI":
                close()
                break;
        }
    });
})
soundSpt = {
    init: function () {
        document.onkeyup = function (data) {
            if (data.which == 27) {
                $("body").hide()
                close()
            }
            if (data.which == 38) {
                execute('volUp')
            }
            if (data.which == 40) {
                execute('volDown')
            }
            if (data.which == 37) {
                execute('back')
            }
            if (data.which == 39) {
                execute('forward')
            }
            if (data.which == 32) {
                execute('play')
            }

        }
    }
}

function close() {
    $("body").hide()
    $.post("http://ps_tify/action", JSON.stringify({ action: "exit" }));
}

function closeplaylist() {
    $("body").hide()
    $.post("http://ps_tify/action", JSON.stringify({ action: "closeplaylist" }));
}


$("#play").click(function () {
    execute('play')
});

$("#pause").click(function () {
    execute('play')
});

$("#loop").click(function () {
    execute('loop')
});

$("#anterior").click(function () {
    execute('back')
});

$("#proximo").click(function () {
    execute('forward')
});

$("#proximo").click(function () {
    execute('forward')
});


var elems = document.querySelectorAll('[data-target]');
for (var i = 0; i < elems.length; i++) {
    elems[i].addEventListener('click', function () {
        atrib(this.getAttribute('data-target'))
    });
}

function postPlaylist() {
    let playlist = $("#btnPlaylist").val();
    var settings = {
        "url": "http://189.1.172.114:5003/playlist",
        "method": "POST",
        "timeout": 0,
        "headers": {
            "Content-Type": "application/json"
        },
        "data": JSON.stringify({
            "nome": playlist,
            "id_xbl": idXBL
        }),
    };

    $.ajax(settings).done(function (response) {
        if (response.error) {
            $("#errorCreatePlaylist").show()
        } else {
            $("#addSongPlaylist").show()
            $("#btnEditPlaylist").show()
            $("#btnAddPlaylist").hide()
            $("#btnIdPlaylist").val(response.id)
        }
    });
}

function myplaylist() {
    let myplaylist = [];
    let playlist = ``;
    $("#listPlaylist").empty();
    var settings = {
        "url": "http://189.1.172.114:5003/playlist/getPlaylist/" + idXBL,
        "method": "GET",
        "timeout": 0,
    };

    $.ajax(settings).done(function (response) {
        playlist += '<h1 class="song__main-title">Minhas playlist</h1>'
        playlist += `<table class="table" style="width: 91%;">
        <thead>
        <tr>
            <th style=" text-align: center;"> Titulo </th>
        </tr>
        </thead>
        <tbody>`
        myplaylist = response.response
        for (let i = 0; i < myplaylist.length; i++) {
            let loop = myplaylist[i]
            playlist += `<tr> 
            <td style=" text-align: center;"><a data-gender="RapCaviar" onclick="myMusicList(${loop.id}, '${loop.nome}')">${loop.nome}</a></td>
            <td >`
            playlist += `</tr>`

        }
        playlist += `</tbody></table>`
        $('#listPlaylist').append(playlist); 
    });
}

function myMusicList(idPlaylist, nome) {
    $('#btnIdPlaylist').val(idPlaylist);
    $('#btnPlaylist').val(nome);
    atrib('myPlaylist')
}


function carregaPlaylist() {
    $("#inner-strip").empty();
    let topPlaylist = ''
    var settings = {
        "url": "http://189.1.172.114:5003/playlist/topPlaylist/",
        "method": "GET",
        "timeout": 0,
    };

    $.ajax(settings).done(function (response) {
        let playlist = response.response
        for (let i = 0; i < playlist.length; i++) {
            let loop = playlist[i]
            let img = "https://i.scdn.co/image/ab67706f000000027e368901f39aae9d510c8fda"
            topPlaylist += `
                    <div class="box-item" data-gender="Trap BR">
                        <div class="box-item__image">
                            <img src="${img}">
                        </div>
                        <h4>${loop.nome}</h4>
                        <h4>${loop.likes} likes</h4>
                    </div>
            `
        }
        $('#inner-strip').append(topPlaylist);
    });
}


